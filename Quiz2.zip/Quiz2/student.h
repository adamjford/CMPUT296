#ifndef _student_h
#define _student_h

typedef struct {
    int id;
    char name[64];
    char grade[3];
} student_info;
#endif
