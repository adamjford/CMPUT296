CMPUT 297 Winter 2012-2013

Quiz 1

Complete the implementation of the linked list version of the queue ADT.

You will have to implement the functions:
    getElement
    deleteElement 

and to add appropriate test cases to testq.c for your new functions.

Zip the entire Quiz1 directory and upload to Moodle when complete.
